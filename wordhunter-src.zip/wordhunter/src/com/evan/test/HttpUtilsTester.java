package com.evan.test;

import com.evan.utils.HttpUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by wangzhen318 on 2017/10/9.
 */
public class HttpUtilsTester {
    @Test
    public void testGet() throws Exception {
        String url = "https://baike.baidu.com/item/Java/85979?fr=aladdin";
        String text = HttpUtils.get(url);
        Assert.assertNotNull(text);
        System.out.println(text);
    }

}
