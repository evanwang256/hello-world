package com.evan;

import com.evan.utils.StringUtils;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangzhen318 on 2017/10/9.
 */
public class Processor {
    /**
     * 字词频率统计
     *
     * @param text
     * @return
     */
    public static Map<String, Integer> countWords(String text) {
        if (StringUtils.isEmpty(text)) {
            throw new IllegalArgumentException("参数不能为空");
        }
        //分词器分词
        List<Term> terms = HanLP.segment(text);
        Map<String, Integer> wordCounts = new HashMap<>();
        for (Term term : terms) {
            String word = term.word.trim();
            if (word.length() == 0) {
                continue;
            }
            Integer count = wordCounts.get(word);
            if (count == null) {
                wordCounts.put(word, 1);
            } else {
                wordCounts.put(word, ++count);
            }
        }
        return wordCounts;
    }

    /**
     * 关键字提取
     *
     * @param text
     * @param size 关键字数量
     * @return
     */
    public static List<String> extractKeyword(String text, int size) {
        return HanLP.extractKeyword(text, size);
    }


}
