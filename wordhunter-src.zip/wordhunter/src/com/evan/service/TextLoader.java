package com.evan.service;

/**
 * 文本获取接口
 */
public interface TextLoader {
    /**
     * 从指定uri获取文本内容
     * @param uri
     * @return
     */
    String load(String uri);
}
