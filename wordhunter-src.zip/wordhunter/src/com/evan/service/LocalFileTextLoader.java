package com.evan.service;

import com.evan.utils.FileUtils;

import java.io.File;
import java.io.IOException;

/**
 * 本地文本获取器.
 */
public class LocalFileTextLoader implements TextLoader {
    @Override
    public String load(String filepath) {
        File file = new File(filepath);
        try {
            return FileUtils.file2String(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
