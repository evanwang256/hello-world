package com.evan.service;

import com.evan.utils.HttpUtils;

import java.io.IOException;

/**
 * 网络文本获取器.
 */
public class NetWorkTextLoader implements TextLoader {
    @Override
    public String load(String url) {
        try {
            return HttpUtils.get(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
