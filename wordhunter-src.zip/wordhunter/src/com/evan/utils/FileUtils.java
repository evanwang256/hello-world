package com.evan.utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;

/**
 * 文件工具类.
 */
public class FileUtils {
    /**
     * 读取文件内容
     *
     * @param file
     * @return 文件内容字符串
     * @throws IOException
     */
    public static String file2String(File file) throws IOException {
        if (file == null || !file.exists() || !file.canRead()) {
            return null;
        }

        try (FileReader reader = new FileReader(file);
             StringWriter writer = new StringWriter()) {
            char[] cbuf = new char[1024];

            int len;
            while ((len = reader.read(cbuf)) != -1) {
                writer.write(cbuf, 0, len);
            }

            String content = writer.toString();
            return content;
        }

    }
}
