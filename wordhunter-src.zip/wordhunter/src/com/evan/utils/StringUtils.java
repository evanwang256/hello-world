package com.evan.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 文本工具类
 */
public class StringUtils {

    public static boolean isEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }

    /**
     * 过滤文本中的html标签和标点符号
     * @param text
     * @return
     */
    public static String filterText(String text) {
        return replacePunctuation(escapeHtml(text));
    }

    /**
     * 将文本里的标点符号默认替换成空格
     *
     * @param text
     * @return
     */
    public static String replacePunctuation(String text) {
        return replacePunctuation(text, " ");
    }

    /**
     * 将文本里的标点符号默认替换指定符号
     *
     * @param text
     * @return
     */
    public static String replacePunctuation(String text, String replacement) {
        return text.replaceAll("\\p{P}", replacement);
    }

    /**
     * 过滤文本中的html标签
     * @param htmlStr
     * @return
     */
    public static String escapeHtml(String htmlStr) {
        String regEx_script="<script[^>]*?>[\\s\\S]*?</script>"; //定义script的正则表达式
        String regEx_style="<style[^>]*?>[\\s\\S]*?</style>"; //定义style的正则表达式
        String regEx_html="<[^>]+>"; //定义HTML标签的正则表达式

        Pattern p_script= Pattern.compile(regEx_script,Pattern.CASE_INSENSITIVE);
        Matcher m_script=p_script.matcher(htmlStr);
        htmlStr=m_script.replaceAll(""); //过滤script标签

        Pattern p_style=Pattern.compile(regEx_style,Pattern.CASE_INSENSITIVE);
        Matcher m_style=p_style.matcher(htmlStr);
        htmlStr=m_style.replaceAll(""); //过滤style标签

        Pattern p_html=Pattern.compile(regEx_html,Pattern.CASE_INSENSITIVE);
        Matcher m_html=p_html.matcher(htmlStr);
        htmlStr=m_html.replaceAll(""); //过滤html标签

        htmlStr = htmlStr.replaceAll("nbsp", "");//去除空格

        return htmlStr.trim(); //返回文本字符串
    }


}
