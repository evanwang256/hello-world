package com.evan.utils;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * http工具读取网络内容工具类.
 */
public class HttpUtils {

    /**
     * get请求
     *
     * @param url url地址，含参数
     * @return
     * @throws IOException
     */
    public static String get(String url) throws IOException {
        URL getUrl = new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) getUrl
                .openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.connect();

        int respCode = urlConnection.getResponseCode();
        //请求成功
        if (HttpURLConnection.HTTP_OK == respCode) {
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(urlConnection.getInputStream(), "UTF-8"));
            String readLine;
            StringBuffer response = new StringBuffer();
            while (null != (readLine = bufferedReader.readLine())) {
                response.append(readLine);
            }

            bufferedReader.close();
            return response.toString();
        }
        //请求失败
        return null;
    }

}
